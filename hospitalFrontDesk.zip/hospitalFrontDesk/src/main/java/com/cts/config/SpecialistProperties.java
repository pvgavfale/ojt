package com.cts.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.cts.pojo.DoctorDetails;

@Configuration
@ConfigurationProperties(prefix ="specialist" )
@PropertySource("classpath:specialist.properties")
public class SpecialistProperties {
	
	List<DoctorDetails> doctorDetails=new ArrayList<>();

	public List<DoctorDetails> getDoctorDetails() {
		return doctorDetails;
	}

	public void setDoctorDetails(List<DoctorDetails> doctorDetails) {
		this.doctorDetails = doctorDetails;
	}
	
	
	
}
