package com.cts.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.cts.pojo.Hospital;

@Configuration
@ConfigurationProperties(prefix ="hospital" )
@PropertySource("classpath:specialist.properties")
public class HospitalProperties {
	
	private List<Hospital> allHospitals =new ArrayList<>();

	public List<Hospital> getAllHospitals() {
		return allHospitals;
	}

	public void setAllHospitals(List<Hospital> allHospitals) {
		this.allHospitals = allHospitals;
	}

}
