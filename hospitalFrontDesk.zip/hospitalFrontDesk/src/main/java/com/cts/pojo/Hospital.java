package com.cts.pojo;

public class Hospital {

	private String name;
	private String hospitalId;
	private int totalBeds;
	public Hospital(String name, String hospitalId, int totalBeds) {
		super();
		this.name = name;
		this.hospitalId = hospitalId;
		this.totalBeds = totalBeds;
	}
	public Hospital() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public int getTotalBeds() {
		return totalBeds;
	}
	public void setTotalBeds(int totalBeds) {
		this.totalBeds = totalBeds;
	}


}
