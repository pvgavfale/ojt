package com.cts.pojo;

public class AppointmentDetails {
	
	private String patientName;
	private String specialistName;
	private String appointmentDay;
	private String appointmentTime;
	
	
	
	public AppointmentDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AppointmentDetails(String patientName, String specialistName, String appointmentDay,
			String appointmentTime) {
		super();
		this.patientName = patientName;
		this.specialistName = specialistName;
		this.appointmentDay = appointmentDay;
		this.appointmentTime = appointmentTime;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getSpecialistName() {
		return specialistName;
	}
	public void setSpecialistName(String specialistName) {
		this.specialistName = specialistName;
	}
	public String getAppointmentDay() {
		return appointmentDay;
	}
	public void setAppointmentDay(String appointmentDay) {
		this.appointmentDay = appointmentDay;
	}
	public String getAppointmentTime() {
		return appointmentTime;
	}
	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}

}
