package com.cts.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.config.SpecialistProperties;
import com.cts.exception.DataNotFoundException;
import com.cts.pojo.AppointmentDetails;
import com.cts.pojo.DoctorDetails;
import com.cts.services.HospitalServices;

@RestController
@CrossOrigin
@RequestMapping("/api/helpdesk")
public class HospitalFrontDeskController {
	@Autowired
	private SpecialistProperties specialistProperties;
	
	@Autowired
	private HospitalServices hospitalServices;
	
	@GetMapping(value="/")
	public String greetings() {
		
		return "Welcome to Hospital Front desk!!";
	}

	/**
	 * Return all possible specialist
	 */
	@GetMapping(value="/specialist")
	public List<DoctorDetails> getAllSpecialist() 
	{
		System.out.println("getting all specialist "+specialistProperties.getDoctorDetails());
		
		return specialistProperties.getDoctorDetails();
	}
	
	@GetMapping(value="/specialist/{hospitalId}/{type}")
	public List<DoctorDetails> getSpecialistByType(@PathVariable(value ="hospitalId")  String hospitalId,@PathVariable(value = "type") String type) 
	{
		
		System.out.println(">>>"+hospitalId+">>>>"+type);
		List<DoctorDetails> details = specialistProperties.getDoctorDetails().stream().filter((i->(i.getHospitalId().equals(hospitalId) && i.getType().equals(type)))).collect(Collectors.toList());
		
		System.out.println(details);
		if(CollectionUtils.isEmpty(details)) {
			throw new DataNotFoundException("No Records Found!!");	
		}
		return details;
	}
	
	@GetMapping(value="/getBedsAvaialble/{hospitalId}")
	public String getBedsAvailable(@PathVariable String hospitalId) 
	{
		//System.out.println("getting all specialist "+specialistProperties.getDoctorDetails());
		int totalBeds=hospitalServices.totalBedsAvailable(hospitalId);
		if(totalBeds<1) {
			throw new DataNotFoundException("No beds available");
		}
		String output="Number of Beds Available is ="+totalBeds;
		return output;
	}
	
	
	/**
	 * Return appointment details
	 * @param details
	 * @return
	 */
	@PostMapping(value ="/book")
	@ExceptionHandler(value = DataNotFoundException.class)
	public AppointmentDetails bookAppointment(@RequestBody  AppointmentDetails details) {
		boolean recordFound =false;
		for (DoctorDetails docDetails : specialistProperties.getDoctorDetails()) {
			System.out.println(">>>>>>"+docDetails.getName());
			if(docDetails.getName().equals(details.getSpecialistName())) {
				details.setAppointmentTime(docDetails.getAvailableTime());
				recordFound=true;
			}		
		}
		if(!recordFound) {
			
			throw new DataNotFoundException("No data Found!!");
		
	}		
		return details;
	}
}
