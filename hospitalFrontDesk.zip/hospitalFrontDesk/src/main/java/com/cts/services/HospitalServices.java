package com.cts.services;

import java.util.List;
import java.util.stream.Collectors;
import com.cts.pojo.Hospital;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.cts.config.HospitalProperties;

@Service
public class HospitalServices {
	
	@Autowired
	HospitalProperties hospitalProperties;
	

	public int totalBedsAvailable(String hospitalId) {
		System.out.println(hospitalProperties.getAllHospitals().size());
		List<Hospital> hospitals=hospitalProperties.getAllHospitals().stream().filter(i -> i.getHospitalId().equals(hospitalId))
				.collect(Collectors.toList());
		 int totalBeds=0;
		 if(!CollectionUtils.isEmpty(hospitals)) {
			totalBeds=hospitals.get(0).getTotalBeds(); 
		 }
		
		 
		 return totalBeds;
				 
				 
				 
	}
}
