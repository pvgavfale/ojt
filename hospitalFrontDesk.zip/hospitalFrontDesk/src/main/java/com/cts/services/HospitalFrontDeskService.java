package com.cts.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cts.pojo.DoctorDetails;

@Service
public class HospitalFrontDeskService {
	
	private static final String HOSPITAL_HELP_DESK_URL = "http://localhost:8080/api/helpdesk/";

	@Autowired
	private RestTemplate restTemplate;
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	public  List<DoctorDetails> getAllSpecialistByType(String type,String hospitalId) {
		
		List<DoctorDetails> details = (List<DoctorDetails>) restTemplate.getForObject(HOSPITAL_HELP_DESK_URL + "/specialist/" + hospitalId + "/"+type, DoctorDetails.class);
		return details;
	}
}
